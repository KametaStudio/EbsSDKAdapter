//
//  EbsSDKAdapter.h
//  EbsSDKAdapter
//
//  Created by Serge Rybchinsky on 23/04/2019.
//  Copyright © 2019 Serge Rybchinsky. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for EbsSDKAdapter.
FOUNDATION_EXPORT double EbsSDKVersionNumber;

//! Project version string for EbsSDKAdapter.
FOUNDATION_EXPORT const unsigned char EbsSDKAdapterVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <EbsSDKAdapter/PublicHeader.h>


